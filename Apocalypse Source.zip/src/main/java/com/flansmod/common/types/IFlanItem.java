package com.flansmod.common.types;

public interface IFlanItem 
{
	public InfoType getInfoType();
}

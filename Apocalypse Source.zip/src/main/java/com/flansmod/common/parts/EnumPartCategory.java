package com.flansmod.common.parts;

public enum EnumPartCategory 
{
	COCKPIT, WING, ENGINE, PROPELLER, BAY, TAIL, WHEEL, CHASSIS, TURRET, FUEL, MISC;
}

package com.flansmod.common.guns;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public abstract class EntityShootable extends Entity 
{
	public EntityShootable(World w) 
	{
		super(w);
	}
}

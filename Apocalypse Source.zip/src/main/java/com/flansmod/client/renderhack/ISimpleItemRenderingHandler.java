package com.flansmod.client.renderhack;

public interface ISimpleItemRenderingHandler extends ITextureHandler 
{

}

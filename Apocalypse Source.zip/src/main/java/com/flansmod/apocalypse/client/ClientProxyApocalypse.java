package com.flansmod.apocalypse.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import com.flansmod.apocalypse.client.model.RenderSurvivor;
import com.flansmod.apocalypse.common.CommonProxyApocalypse;
import com.flansmod.apocalypse.common.FlansModApocalypse;
import com.flansmod.apocalypse.common.entity.EntitySurvivor;
import com.flansmod.apocalypse.common.network.PacketApocalypseCountdown;
import com.flansmod.client.model.RenderItemHolder;
import com.flansmod.client.renderhack.ITextureHandler;
import com.flansmod.client.renderhack.RenderRegistry;
import com.flansmod.client.renderhack.RenderSpawner;
import com.flansmod.common.FlansMod;
import com.flansmod.common.driveables.EntityDriveable;
import com.flansmod.common.driveables.EntitySeat;

public class ClientProxyApocalypse extends CommonProxyApocalypse 
{
	public static int apocalypseCountdown = 0;
	
	public void preInit(FMLPreInitializationEvent event)
	{
		super.preInit(event);
		MinecraftForge.EVENT_BUS.register(new ApocalypseModelManager());
		ApocalypseModelManager.registerVariants();
	}
	
	public void init(FMLInitializationEvent event)
	{
		super.init(event);
		registerVanillaItemModel(FlansModApocalypse.sulphur, Item.getItemFromBlock(FlansModApocalypse.blockSulphur), Item.getItemFromBlock(FlansModApocalypse.blockSulphuricAcid));
		
		RenderingRegistry.registerEntityRenderingHandler(EntitySurvivor.class, new RenderSurvivor(Minecraft.getMinecraft().getRenderManager(), new ModelBiped(), 0));
	}
	
	private void registerVanillaItemModel(Item... items)
	{
		for(Item item : items)
			Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, new ModelResourceLocation(FlansModApocalypse.MODID + ":" + item.getUnlocalizedName().split("\\.")[1], "inventory"));	
	}
	
	public void postInit(FMLPostInitializationEvent event) 
	{
		super.postInit(event);
	}
	
	public static void updateApocalypseCountdownTimer(int i)
	{
		apocalypseCountdown = i; 
	}
	
	/** Tick hook for client logic */
	@SubscribeEvent
	public void tick(TickEvent.ClientTickEvent event)
	{
		if(event.phase == TickEvent.Phase.START)
		{
			if(apocalypseCountdown > 0)
			{
				apocalypseCountdown--;
			}
		}
	}
	
	/** Tick hook for client render */
	@SubscribeEvent
	public void tick(TickEvent.RenderTickEvent event)
	{
		if(event.phase == TickEvent.Phase.START)
		{

		}
	}
	
	@SubscribeEvent
	public void eventHandler(RenderGameOverlayEvent event)
	{
		Minecraft mc = Minecraft.getMinecraft();
		//DEBUG vehicles
		if(apocalypseCountdown > 0)
		{		
			mc.fontRendererObj.drawString("Seconds to the apocalypse: " + (apocalypseCountdown / 20), 2, 2, 0xffffff);
		}
	}
}

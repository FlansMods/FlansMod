package com.flansmod.apocalypse.common.world;

import net.minecraft.block.BlockPortal;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.Teleporter;
import net.minecraft.world.WorldServer;

public class TeleporterApocalypse extends Teleporter 
{
	private WorldServer world;
	
	public TeleporterApocalypse(WorldServer world) 
	{
		super(world);
		this.world = world;
	}
	
	@Override
	public boolean makePortal(Entity entity)
    {
		return true;
    }


}

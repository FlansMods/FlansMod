package com.flansmod.apocalypse.common.entity;

import java.util.ArrayList;

import com.flansmod.apocalypse.common.FlansModApocalypse;
import com.flansmod.common.guns.EnumFireMode;
import com.flansmod.common.guns.GunType;
import com.flansmod.common.guns.ShootableType;

import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class EntitySurvivor extends EntityFlansModShooter 
{	
	public static ArrayList<GunType> validGuns;
	
	public EntitySurvivor(World world) 
	{
		super(world);
		if(!world.isRemote)
		{
			if(validGuns == null)
				initGunList();
			
			//Pick a random gun for this survivor
			GunType gun = validGuns.get(world.rand.nextInt(validGuns.size()));
			ItemStack gunStack = FlansModApocalypse.getLootGenerator().loadAndPaintGun(gun, world.rand);
			this.setCurrentItemOrArmor(0, gunStack);
			//Add random armour
			FlansModApocalypse.getLootGenerator().dressMeUp(this, world.rand);
			
			ammoStacks = new ItemStack[5];
			for(int i = 0; i < world.rand.nextInt(4) + 2; i++)
			{
				ShootableType type = gun.ammo.get(world.rand.nextInt(gun.ammo.size()));
				ammoStacks[i] = new ItemStack(type.item);
			}
		}
	    targetTasks.addTask(4, new EntityAINearestAttackableTarget(this, EntityFlansModShooter.class, true));
        //tasks.addTask(5, new EntityAIGoSomewhere(this, 1.0D, world.rand.nextDouble() * 10D, world.rand.nextDouble() * 10D));
	}
	
	/** Grab the list of guns valid for survivors from the complete gun list */
	private void initGunList()
	{
		validGuns = new ArrayList<GunType>();
		for(GunType gun : GunType.gunList)
		{
			if(gun.mode == EnumFireMode.SEMIAUTO && !gun.deployable && gun.ammo.size() > 0 && !gun.shield && gun.usableByPlayers && gun.dungeonChance != 0)
				validGuns.add(gun);
		}
	}

}

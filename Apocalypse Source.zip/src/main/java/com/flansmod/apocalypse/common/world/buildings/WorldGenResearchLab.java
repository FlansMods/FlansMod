package com.flansmod.apocalypse.common.world.buildings;

import java.util.Random;

import com.flansmod.apocalypse.common.FlansModApocalypse;
import com.flansmod.common.BlockItemHolder;
import com.flansmod.common.TileEntityItemHolder;

import net.minecraft.block.BlockChest;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class WorldGenResearchLab extends WorldGenFlan 
{
	@Override
	public boolean generate(World world, Random rand, BlockPos pos) 
	{
		int chunkX = ModuloHelper.divide(pos.getX(), 16);
		int chunkZ = ModuloHelper.divide(pos.getZ(), 16);
		
		int structureX = ModuloHelper.divide(chunkX, 3);
		int structureZ = ModuloHelper.divide(chunkZ, 3);
		
		int pieceX = ModuloHelper.modulo(chunkX, 3);
		int pieceZ = ModuloHelper.modulo(chunkZ, 3);
		
		int topLayerHeight = 110;
		
		//Generate empty rooms
		for(int i = 0; i < 8; i++)
		{
			fillArea(world, chunkX * 16, topLayerHeight - 8 * i, chunkZ * 16, chunkX * 16 + 16, topLayerHeight - 8 * i + 8, chunkZ * 16 + 16, FlansModApocalypse.blockLabStone.getDefaultState(), Blocks.air.getDefaultState());			
			fillArea(world, chunkX * 16, topLayerHeight - 8 * i + 6, chunkZ * 16, chunkX * 16 + 16, topLayerHeight - 8 * i + 7, chunkZ * 16 + 16, FlansModApocalypse.blockLabStone.getDefaultState());	
			//Add glowstone lights
			for(int j = 0; j < 2; j++)
			{
				for(int k = 0; k < 2; k++)
				{
					fillArea(world, chunkX * 16 + 3 + 8 * j, topLayerHeight - 8 * i + 6, chunkZ * 16 + 3 + 8 * k, chunkX * 16 + 5 + 8 * j, topLayerHeight - 8 * i + 7, chunkZ * 16 + 5 + 8 * k, Blocks.glowstone.getDefaultState());
					for(int x = 0; x < 2; x++)
					{
						for(int z = 0; z < 2; z++)
						{
							world.setLightFor(EnumSkyBlock.BLOCK, new BlockPos(chunkX * 16 + 3 + 8 * j + x, topLayerHeight - 8 * i + 6, chunkZ * 16 + 3 + 8 * k + z), 15);
							world.getLightFromNeighborsFor(EnumSkyBlock.BLOCK, new BlockPos(chunkX * 16 + 3 + 8 * j + x, topLayerHeight - 8 * i + 5, chunkZ * 16 + 3 + 8 * k + z));
						}
					}		
				}
			}
			
			//Make doors
			if(pieceX != 0)
				fillArea(world, chunkX * 16 + 0, topLayerHeight - 8 * i + 1, chunkZ * 16 + 7, chunkX * 16 + 1, topLayerHeight - 8 * i + 4, chunkZ * 16 + 9, Blocks.air.getDefaultState());			
			if(pieceX != 2)
				fillArea(world, chunkX * 16 + 15, topLayerHeight - 8 * i + 1, chunkZ * 16 + 7, chunkX * 16 + 16, topLayerHeight - 8 * i + 4, chunkZ * 16 + 9, Blocks.air.getDefaultState());			
			if(pieceZ != 0)
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i + 1, chunkZ * 16 + 0, chunkX * 16 + 9, topLayerHeight - 8 * i + 4, chunkZ * 16 + 1, Blocks.air.getDefaultState());			
			if(pieceZ != 2)
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i + 1, chunkZ * 16 + 15, chunkX * 16 + 9, topLayerHeight - 8 * i + 4, chunkZ * 16 + 16, Blocks.air.getDefaultState());	
			
			for(int j = 0; j < 16; j++)
			{
				for(int k = 0; k < 16; k++)
				{
					//world.checkLightFor(EnumSkyBlock.BLOCK, new BlockPos(chunkX * 16 + j, topLayerHeight - 8 * i + 4, chunkZ * 18 + k));
				}
			}
		}
		//Populate rooms
		for(int i = 0; i < 8; i++)
		{
			switch(rand.nextInt(3))
			{
			case 0 : //Stairs
			{
				//Make hole
				fillArea(world, chunkX * 16 + 4, topLayerHeight - 8 * i + 1, chunkZ * 16 + 4, chunkX * 16 + 12, topLayerHeight - 8 * i + 2, chunkZ * 16 + 12, Blocks.nether_brick_fence.getDefaultState());	
				fillArea(world, chunkX * 16 + 5, topLayerHeight - 8 * i - 2, chunkZ * 16 + 5, chunkX * 16 + 11, topLayerHeight - 8 * i + 2, chunkZ * 16 + 11, Blocks.air.getDefaultState());	
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i + 1, chunkZ * 16 + 11, chunkX * 16 + 9, topLayerHeight - 8 * i + 2, chunkZ * 16 + 12, Blocks.air.getDefaultState());	
				
				//Build stairs
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i - 1, chunkZ * 16 + 9, chunkX * 16 + 9, topLayerHeight - 8 * i, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 5, topLayerHeight - 8 * i - 2, chunkZ * 16 + 9, chunkX * 16 + 7, topLayerHeight - 8 * i - 1, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 9, topLayerHeight - 8 * i - 2, chunkZ * 16 + 9, chunkX * 16 + 11, topLayerHeight - 8 * i - 1, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 9, topLayerHeight - 8 * i - 3, chunkZ * 16 + 7, chunkX * 16 + 11, topLayerHeight - 8 * i - 2, chunkZ * 16 + 9, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 5, topLayerHeight - 8 * i - 3, chunkZ * 16 + 7, chunkX * 16 + 7, topLayerHeight - 8 * i - 2, chunkZ * 16 + 9, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 5, topLayerHeight - 8 * i - 4, chunkZ * 16 + 5, chunkX * 16 + 11, topLayerHeight - 8 * i - 3, chunkZ * 16 + 7, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i - 5, chunkZ * 16 + 7, chunkX * 16 + 9, topLayerHeight - 8 * i - 4, chunkZ * 16 + 9, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i - 6, chunkZ * 16 + 9, chunkX * 16 + 9, topLayerHeight - 8 * i - 5, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 7, topLayerHeight - 8 * i - 7, chunkZ * 16 + 11, chunkX * 16 + 9, topLayerHeight - 8 * i - 6, chunkZ * 16 + 13, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 5, topLayerHeight - 8 * i - 7, chunkZ * 16 + 9, chunkX * 16 + 7, topLayerHeight - 8 * i - 6, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				fillArea(world, chunkX * 16 + 9, topLayerHeight - 8 * i - 7, chunkZ * 16 + 9, chunkX * 16 + 11, topLayerHeight - 8 * i - 6, chunkZ * 16 + 11, FlansModApocalypse.blockLabStone.getDefaultState());	
				
				i++;
				break;
			}
			case 1 : //Liquids room
			{
				for(int j = 0; j < 2; j++)
				{
					for(int k = 0; k < 2; k++)
					{
						if(rand.nextInt(3) == 0)
						{
							generateLiquidsLab(world, rand, chunkX * 16 + 1 + 8 * j, topLayerHeight - 8 * i + 1, chunkZ * 16 + 1 + 8 * k);
						}
						else generateLiquidContainer(world, rand, chunkX * 16 + 2 + 8 * j, topLayerHeight - 8 * i + 1, chunkZ * 16 + 2 + 8 * k, getRandomLiquid(rand));
					}
				}
				break;
			}
			case 2 : //Gun range
			{
				for(int j = 0; j < 2; j++)
				{
					generateTarget(world, rand, chunkX * 16 + 2 + 7 * j, topLayerHeight - 8 * i + 1, chunkZ * 16 + 1);
				}
				fillArea(world, chunkX * 16 + 3, topLayerHeight - 8 * i + 1, chunkZ * 16 + 6, chunkX * 16 + 4, topLayerHeight - 8 * i + 2, chunkZ * 16 + 12, Blocks.planks.getDefaultState());
				fillArea(world, chunkX * 16 + 12, topLayerHeight - 8 * i + 1, chunkZ * 16 + 6, chunkX * 16 + 13, topLayerHeight - 8 * i + 2, chunkZ * 16 + 12, Blocks.planks.getDefaultState());
				fillArea(world, chunkX * 16 + 4, topLayerHeight - 8 * i + 1, chunkZ * 16 + 11, chunkX * 16 + 12, topLayerHeight - 8 * i + 2, chunkZ * 16 + 12, Blocks.stone_slab.getStateFromMeta(10));
				world.setBlockState(new BlockPos(chunkX * 16 + 6, topLayerHeight - 8 * i + 1, chunkZ * 16 + 11), Blocks.planks.getDefaultState());
				world.setBlockState(new BlockPos(chunkX * 16 + 9, topLayerHeight - 8 * i + 1, chunkZ * 16 + 11), Blocks.planks.getDefaultState());
				
				generateGunRack(world, rand, chunkX * 16 + 1, topLayerHeight - 8 * i + 1, chunkZ * 16 + 14);
				generateGunRack(world, rand, chunkX * 16 + 4, topLayerHeight - 8 * i + 1, chunkZ * 16 + 14);
				generateGunRack(world, rand, chunkX * 16 + 10, topLayerHeight - 8 * i + 1, chunkZ * 16 + 14);
				generateGunRack(world, rand, chunkX * 16 + 13, topLayerHeight - 8 * i + 1, chunkZ * 16 + 14);
				
				break;
			}
			}
		}
		

		
		
		return false;
	}
	
	private void generateGunRack(World world, Random rand, int x, int y, int z)
	{
		fillArea(world, x, y, z, x + 2, y + 1, z + 1, Blocks.planks.getDefaultState());
		fillArea(world, x, y + 1, z, x + 2, y + 2, z + 1, FlansModApocalypse.gunRack.getDefaultState().withProperty(BlockItemHolder.FACING, EnumFacing.SOUTH));		
		for(int i = 0; i < 2; i++)
		{
			if(rand.nextInt(3) != 0)
				((TileEntityItemHolder)world.getTileEntity(new BlockPos(x + i, y + 1, z))).addRandomLoot(rand);
		}
	}
	
	private void generateTarget(World world, Random rand, int x, int y, int z)
	{
		fillArea(world, x + 1, y + 1, z, x + 4, y + 4, z + 1, Blocks.wool.getStateFromMeta(14));
		world.setBlockState(new BlockPos(x + 2, y, z), Blocks.wool.getStateFromMeta(14));
		world.setBlockState(new BlockPos(x + 2, y + 4, z), Blocks.wool.getStateFromMeta(14));
		world.setBlockState(new BlockPos(x, y + 2, z), Blocks.wool.getStateFromMeta(14));
		world.setBlockState(new BlockPos(x + 4, y + 2, z), Blocks.wool.getStateFromMeta(14));
		world.setBlockState(new BlockPos(x + 2, y + 1, z), Blocks.wool.getDefaultState());
		world.setBlockState(new BlockPos(x + 2, y + 3, z), Blocks.wool.getDefaultState());
		world.setBlockState(new BlockPos(x + 1, y + 2, z), Blocks.wool.getDefaultState());
		world.setBlockState(new BlockPos(x + 3, y + 2, z), Blocks.wool.getDefaultState());
	}
	
	private void generateLiquidsLab(World world, Random rand, int x, int y, int z)
	{
		fillArea(world, x, y, z, x + 4, y + 1, z + 1, Blocks.quartz_block.getDefaultState());
		fillArea(world, x + 1, y, z, x + 3, y + 1, z + 1, Blocks.stone_slab.getStateFromMeta(15));
		
		fillArea(world, x, y, z + 5, x + 5, y + 1, z + 6, Blocks.quartz_block.getDefaultState());
		fillArea(world, x + 1, y, z + 5, x + 4, y + 1, z + 6, Blocks.stone_slab.getStateFromMeta(15));
		
		world.setBlockState(new BlockPos(x + 5, y, z + 5), Blocks.cauldron.getStateFromMeta(rand.nextInt(4)));
		
		world.setBlockState(new BlockPos(x + 4, y, z), Blocks.chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.SOUTH));
		world.setBlockState(new BlockPos(x + 5, y, z), Blocks.chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.SOUTH));
		
		//Fill chests
        TileEntity tileentity = world.getTileEntity(new BlockPos(x + 4, y, z));
        if (tileentity instanceof TileEntityChest)
        {
        	FlansModApocalypse.getLootGenerator().fillLiquidLabChest(rand, (TileEntityChest)tileentity);
        }
        
        tileentity = world.getTileEntity(new BlockPos(x + 5, y, z));
        if (tileentity instanceof TileEntityChest)
        {
        	FlansModApocalypse.getLootGenerator().fillLiquidLabChest(rand, (TileEntityChest)tileentity);
        }
		
		//Brewing stands
		BlockPos pos = new BlockPos(x + rand.nextInt(4), y + 1, z);
		world.setBlockState(pos, Blocks.brewing_stand.getDefaultState());
        tileentity = world.getTileEntity(pos);
        if (tileentity instanceof TileEntityBrewingStand)
        {
        	FlansModApocalypse.getLootGenerator().fillBrewingStand(rand, (TileEntityBrewingStand)tileentity);
        }
		
		pos = new BlockPos(x + rand.nextInt(5), y + 1, z + 5);
		world.setBlockState(pos, Blocks.brewing_stand.getDefaultState());
        tileentity = world.getTileEntity(pos);
        if (tileentity instanceof TileEntityBrewingStand)
        {
        	FlansModApocalypse.getLootGenerator().fillBrewingStand(rand, (TileEntityBrewingStand)tileentity);
        }
	}
	
	private void generateLiquidContainer(World world, Random rand, int x, int y, int z, IBlockState liquid)
	{
		fillArea(world, x, y, z, x + 4, y + 5, z + 4, FlansModApocalypse.blockLabStone.getDefaultState());
		fillArea(world, x, y + 1, z, x + 4, y + 4, z + 4, Blocks.glass.getDefaultState());
		
		fillArea(world, x + 1, y, z + 1, x + 3, y + 5, z + 3, Blocks.air.getDefaultState());
		fillArea(world, x + 1, y, z + 1, x + 3, y + rand.nextInt(4), z + 3, liquid);		
		
		fillArea(world, x, y, z, 			x + 1, y + 5, z + 1, Blocks.air.getDefaultState());
		fillArea(world, x + 3, y, z, 		x + 4, y + 5, z + 1, Blocks.air.getDefaultState());
		fillArea(world, x + 3, y, z + 3, 	x + 4, y + 5, z + 4, Blocks.air.getDefaultState());
		fillArea(world, x, y, z + 3, 		x + 1, y + 5, z + 4, Blocks.air.getDefaultState());
	}
	
	private IBlockState getRandomLiquid(Random rand)
	{
		switch(rand.nextInt(3))
		{
		case 0 : return Blocks.water.getDefaultState();
		case 1 : return Blocks.lava.getDefaultState();
		case 2 : return FlansModApocalypse.blockSulphuricAcid.getDefaultState();
		}
		
		return Blocks.water.getDefaultState();
	}
	
	private void generateRoom(World world, Random rand, int chunkX, int layerY, int chunkZ)
	{
		
	}
}

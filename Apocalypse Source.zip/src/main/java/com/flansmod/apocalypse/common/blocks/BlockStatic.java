package com.flansmod.apocalypse.common.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockStatic extends Block
{
	public BlockStatic(Material material) 
	{
		super(material);
	}

}

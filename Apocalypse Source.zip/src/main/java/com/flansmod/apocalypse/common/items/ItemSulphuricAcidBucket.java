package com.flansmod.apocalypse.common.items;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBucket;

public class ItemSulphuricAcidBucket extends ItemBucket 
{
	public ItemSulphuricAcidBucket(Block containedBlock) 
	{
		super(containedBlock);
	}

}
